
//
//  QNCallBackConst.h
//  QNDeviceSDKDemo
//
//  Created by com.qn.device on 2018/3/31.
//  Copyright © 2018年 com.qn.device. All rights reserved.
//

typedef void(^QNResultCallback) (NSError *error);
